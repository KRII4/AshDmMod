package net.mcreator.biomespls.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.biomespls.entity.AshsoulEntity;
import net.mcreator.biomespls.client.model.Modelscorchsoulfirst;

public class AshsoulRenderer extends MobRenderer<AshsoulEntity, Modelscorchsoulfirst<AshsoulEntity>> {
	public AshsoulRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelscorchsoulfirst(context.bakeLayer(Modelscorchsoulfirst.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<AshsoulEntity, Modelscorchsoulfirst<AshsoulEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("biomespls:textures/ashsoultestlight.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(AshsoulEntity entity) {
		return new ResourceLocation("biomespls:textures/ashsoultest.png");
	}
}
