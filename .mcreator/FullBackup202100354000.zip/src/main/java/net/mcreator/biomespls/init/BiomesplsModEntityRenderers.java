
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.biomespls.client.renderer.TectslimeRenderer;
import net.mcreator.biomespls.client.renderer.AshsoulRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BiomesplsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(BiomesplsModEntities.THROWING_TORCH, ThrownItemRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.ASHSOUL, AshsoulRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.TECTSLIME, TectslimeRenderer::new);
	}
}
