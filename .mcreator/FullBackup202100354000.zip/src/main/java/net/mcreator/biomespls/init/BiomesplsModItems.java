
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.biomespls.item.ThrowingTorchItem;
import net.mcreator.biomespls.item.ScorchedDimensionItem;
import net.mcreator.biomespls.item.PilentiumItem;
import net.mcreator.biomespls.item.ElementalShardItem;
import net.mcreator.biomespls.item.ElementItem;
import net.mcreator.biomespls.item.AshwaterItem;
import net.mcreator.biomespls.item.AshSoulHeartItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BiomesplsModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item ASHGRASS = register(BiomesplsModBlocks.ASHGRASS, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item SCORCHEDEARTH = register(BiomesplsModBlocks.SCORCHEDEARTH, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ASH_ROCK = register(BiomesplsModBlocks.ASH_ROCK, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item SCORCHED_DIMENSION = register(new ScorchedDimensionItem());
	public static final Item ASHWATER_BUCKET = register(new AshwaterItem());
	public static final Item SCORCHED_WOOD = register(BiomesplsModBlocks.SCORCHED_WOOD, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ELEMENTAL_ORE_BLOCK = register(BiomesplsModBlocks.ELEMENTAL_ORE_BLOCK, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ASH_COAL = register(BiomesplsModBlocks.ASH_COAL, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ELEMENT = register(new ElementItem());
	public static final Item BROKEN_ASH_STONE = register(BiomesplsModBlocks.BROKEN_ASH_STONE, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ELEMENTAL_SHARD = register(new ElementalShardItem());
	public static final Item VERY_BREAKED_ASH_STONE = register(BiomesplsModBlocks.VERY_BREAKED_ASH_STONE, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item THROWING_TORCH = register(new ThrowingTorchItem());
	public static final Item PILENTIUM_ORE = register(BiomesplsModBlocks.PILENTIUM_ORE, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item PILENTIUM = register(new PilentiumItem());
	public static final Item SCORCH_WOOD_NO_FLAME = register(BiomesplsModBlocks.SCORCH_WOOD_NO_FLAME, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final Item ASHSOUL = register(
			new SpawnEggItem(BiomesplsModEntities.ASHSOUL, -14408668, -4499968, new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME))
					.setRegistryName("ashsoul_spawn_egg"));
	public static final Item ASH_SOUL_HEART = register(new AshSoulHeartItem());
	public static final Item TECTSLIME = register(
			new SpawnEggItem(BiomesplsModEntities.TECTSLIME, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("tectslime_spawn_egg"));

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
