
package net.mcreator.biomespls.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.biomespls.init.BiomesplsModItems;
import net.mcreator.biomespls.init.BiomesplsModFluids;
import net.mcreator.biomespls.init.BiomesplsModBlocks;

public abstract class AshwaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> BiomesplsModFluids.ASHWATER,
			() -> BiomesplsModFluids.FLOWING_ASHWATER,
			FluidAttributes.builder(new ResourceLocation("biomespls:blocks/ashwaterstill"), new ResourceLocation("biomespls:blocks/ashwaterflow"))

	).explosionResistance(100f)

			.tickRate(3)

			.bucket(() -> BiomesplsModItems.ASHWATER_BUCKET).block(() -> (LiquidBlock) BiomesplsModBlocks.ASHWATER);

	private AshwaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public Vec3 getFlow(BlockGetter world, BlockPos pos, FluidState fluidstate) {
		return super.getFlow(world, pos, fluidstate).scale(1.1);
	}

	public static class Source extends AshwaterFluid {
		public Source() {
			super();
			setRegistryName("ashwater");
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends AshwaterFluid {
		public Flowing() {
			super();
			setRegistryName("flowing_ashwater");
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
