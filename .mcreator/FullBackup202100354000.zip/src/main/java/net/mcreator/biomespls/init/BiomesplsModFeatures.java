
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.core.Registry;

import net.mcreator.biomespls.world.features.ores.VeryBreakedAshStoneFeature;
import net.mcreator.biomespls.world.features.ores.ScorchedearthFeature;
import net.mcreator.biomespls.world.features.ores.ElementalOreBlockFeature;
import net.mcreator.biomespls.world.features.ores.BrokenAshStoneFeature;
import net.mcreator.biomespls.world.features.ores.AshCoalFeature;
import net.mcreator.biomespls.world.features.lakes.AshwaterFeature;
import net.mcreator.biomespls.world.features.Scws9Feature;
import net.mcreator.biomespls.world.features.Scws7Feature;
import net.mcreator.biomespls.world.features.Scws6Feature;
import net.mcreator.biomespls.world.features.Scws5Feature;
import net.mcreator.biomespls.world.features.Scws4Feature;
import net.mcreator.biomespls.world.features.Scws3Feature;
import net.mcreator.biomespls.world.features.Scws2Feature;
import net.mcreator.biomespls.world.features.Scws1Feature;
import net.mcreator.biomespls.world.features.Scws19Feature;
import net.mcreator.biomespls.world.features.Scws18Feature;
import net.mcreator.biomespls.world.features.Scws17Feature;
import net.mcreator.biomespls.world.features.Scws16Feature;
import net.mcreator.biomespls.world.features.Scws14Feature;
import net.mcreator.biomespls.world.features.Scws13Feature;
import net.mcreator.biomespls.world.features.Scws12Feature;
import net.mcreator.biomespls.world.features.Scws11Feature;
import net.mcreator.biomespls.world.features.Scws10Feature;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BiomesplsModFeatures {
	private static final Map<Feature<?>, FeatureRegistration> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(ScorchedearthFeature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES,
				ScorchedearthFeature.GENERATE_BIOMES, ScorchedearthFeature.CONFIGURED_FEATURE));
		REGISTRY.put(AshwaterFeature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.LAKES, AshwaterFeature.GENERATE_BIOMES, AshwaterFeature.CONFIGURED_FEATURE));
		REGISTRY.put(ElementalOreBlockFeature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES,
				ElementalOreBlockFeature.GENERATE_BIOMES, ElementalOreBlockFeature.CONFIGURED_FEATURE));
		REGISTRY.put(AshCoalFeature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, AshCoalFeature.GENERATE_BIOMES,
				AshCoalFeature.CONFIGURED_FEATURE));
		REGISTRY.put(BrokenAshStoneFeature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES,
				BrokenAshStoneFeature.GENERATE_BIOMES, BrokenAshStoneFeature.CONFIGURED_FEATURE));
		REGISTRY.put(VeryBreakedAshStoneFeature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES,
				VeryBreakedAshStoneFeature.GENERATE_BIOMES, VeryBreakedAshStoneFeature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws1Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws1Feature.GENERATE_BIOMES, Scws1Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws2Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws2Feature.GENERATE_BIOMES, Scws2Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws3Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws3Feature.GENERATE_BIOMES, Scws3Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws4Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws4Feature.GENERATE_BIOMES, Scws4Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws5Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws5Feature.GENERATE_BIOMES, Scws5Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws6Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws6Feature.GENERATE_BIOMES, Scws6Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws7Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws7Feature.GENERATE_BIOMES, Scws7Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws9Feature.FEATURE,
				new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws9Feature.GENERATE_BIOMES, Scws9Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws10Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws10Feature.GENERATE_BIOMES,
				Scws10Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws11Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws11Feature.GENERATE_BIOMES,
				Scws11Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws12Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws12Feature.GENERATE_BIOMES,
				Scws12Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws13Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws13Feature.GENERATE_BIOMES,
				Scws13Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws14Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws14Feature.GENERATE_BIOMES,
				Scws14Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws16Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws16Feature.GENERATE_BIOMES,
				Scws16Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws17Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws17Feature.GENERATE_BIOMES,
				Scws17Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws18Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws18Feature.GENERATE_BIOMES,
				Scws18Feature.CONFIGURED_FEATURE));
		REGISTRY.put(Scws19Feature.FEATURE, new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, Scws19Feature.GENERATE_BIOMES,
				Scws19Feature.CONFIGURED_FEATURE));
	}

	@SubscribeEvent
	public static void registerFeature(RegistryEvent.Register<Feature<?>> event) {
		event.getRegistry().registerAll(REGISTRY.keySet().toArray(new Feature[0]));
		REGISTRY.forEach((feature, registration) -> Registry.register(BuiltinRegistries.CONFIGURED_FEATURE, feature.getRegistryName(),
				registration.configuredFeature()));
	}

	@Mod.EventBusSubscriber
	private static class BiomeFeatureLoader {
		@SubscribeEvent
		public static void addFeatureToBiomes(BiomeLoadingEvent event) {
			for (FeatureRegistration registration : REGISTRY.values()) {
				if (registration.biomes() == null || registration.biomes().contains(event.getName())) {
					event.getGeneration().getFeatures(registration.stage()).add(() -> registration.configuredFeature());
				}
			}
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			ConfiguredFeature<?, ?> configuredFeature) {
	}
}
