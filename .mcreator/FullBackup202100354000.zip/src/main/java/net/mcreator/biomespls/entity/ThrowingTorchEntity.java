
package net.mcreator.biomespls.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fmllegacy.network.NetworkHooks;
import net.minecraftforge.fmllegacy.network.FMLPlayMessages;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.Packet;

import net.mcreator.biomespls.procedures.ThrowingTorchKoghdaSnariadPriziemliaietsiaNaBlokProcedure;
import net.mcreator.biomespls.procedures.ThrowingTorchKoghdaSnariadPopadaietVSushchnostProcedure;
import net.mcreator.biomespls.init.BiomesplsModItems;
import net.mcreator.biomespls.init.BiomesplsModEntities;

import java.util.Random;

@OnlyIn(value = Dist.CLIENT, _interface = ItemSupplier.class)
public class ThrowingTorchEntity extends AbstractArrow implements ItemSupplier {
	public ThrowingTorchEntity(FMLPlayMessages.SpawnEntity packet, Level world) {
		super(BiomesplsModEntities.THROWING_TORCH, world);
	}

	public ThrowingTorchEntity(EntityType<? extends ThrowingTorchEntity> type, Level world) {
		super(type, world);
	}

	public ThrowingTorchEntity(EntityType<? extends ThrowingTorchEntity> type, double x, double y, double z, Level world) {
		super(type, x, y, z, world);
	}

	public ThrowingTorchEntity(EntityType<? extends ThrowingTorchEntity> type, LivingEntity entity, Level world) {
		super(type, entity, world);
	}

	@Override
	public Packet<?> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public ItemStack getItem() {
		return new ItemStack(BiomesplsModItems.THROWING_TORCH);
	}

	@Override
	protected ItemStack getPickupItem() {
		return new ItemStack(BiomesplsModItems.THROWING_TORCH);
	}

	@Override
	protected void doPostHurtEffects(LivingEntity entity) {
		super.doPostHurtEffects(entity);
		entity.setArrowCount(entity.getArrowCount() - 1);
		Entity sourceentity = this.getOwner();
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level;
		Entity imediatesourceentity = this;

		ThrowingTorchKoghdaSnariadPopadaietVSushchnostProcedure.execute(entity);
	}

	@Override
	public void tick() {
		super.tick();
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level;
		Entity entity = this.getOwner();
		Entity imediatesourceentity = this;
		if (this.inGround) {

			ThrowingTorchKoghdaSnariadPriziemliaietsiaNaBlokProcedure.execute(world, x, y, z);
			this.discard();
		}
	}

	public static ThrowingTorchEntity shoot(Level world, LivingEntity entity, Random random, float power, double damage, int knockback) {
		ThrowingTorchEntity entityarrow = new ThrowingTorchEntity(BiomesplsModEntities.THROWING_TORCH, entity, world);
		entityarrow.shoot(entity.getLookAngle().x, entity.getLookAngle().y, entity.getLookAngle().z, power * 2, 0);
		entityarrow.setSilent(true);
		entityarrow.setCritArrow(false);
		entityarrow.setBaseDamage(damage);
		entityarrow.setKnockback(knockback);
		entityarrow.setSecondsOnFire(100);
		world.addFreshEntity(entityarrow);
		world.playSound((Player) null, entity.getX(), entity.getY(), entity.getZ(),
				ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.arrow.shoot")), SoundSource.PLAYERS, 1,
				1f / (random.nextFloat() * 0.5f + 1) + (power / 2));
		return entityarrow;
	}

	public static ThrowingTorchEntity shoot(LivingEntity entity, LivingEntity target) {
		ThrowingTorchEntity entityarrow = new ThrowingTorchEntity(BiomesplsModEntities.THROWING_TORCH, entity, entity.level);
		double d0 = target.getY() + (double) target.getEyeHeight() - 1.1;
		double d1 = target.getX() - entity.getX();
		double d3 = target.getZ() - entity.getZ();
		entityarrow.shoot(d1, d0 - entityarrow.getY() + Math.sqrt(d1 * d1 + d3 * d3) * 0.2F, d3, 1f * 2, 12.0F);
		entityarrow.setSilent(true);
		entityarrow.setBaseDamage(2);
		entityarrow.setKnockback(5);
		entityarrow.setCritArrow(false);
		entityarrow.setSecondsOnFire(100);
		entity.level.addFreshEntity(entityarrow);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		entity.level.playSound((Player) null, (double) x, (double) y, (double) z,
				ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.arrow.shoot")), SoundSource.PLAYERS, 1,
				1f / (new Random().nextFloat() * 0.5f + 1));
		return entityarrow;
	}
}
