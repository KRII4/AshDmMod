
package net.mcreator.biomespls.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.mcreator.biomespls.procedures.AshslimeModelProcedure;
import net.mcreator.biomespls.procedures.AshslimeLayerProcedure;
import net.mcreator.biomespls.entity.AshslimeEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class AshslimeRenderer extends GeoEntityRenderer<AshslimeEntity> {
	public AshslimeRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new AshslimeModelProcedure());
		this.shadowRadius = 0.4f;
		this.addLayer(new AshslimeLayerProcedure(this));
	}

	@Override
	public RenderType getRenderType(AshslimeEntity animatable, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer,
			VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(1.0F, 1.0F, 1.0F);
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}
}
