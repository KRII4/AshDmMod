
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.biomespls.entity.ThrowingTorchEntity;
import net.mcreator.biomespls.entity.LavaslimeEntity;
import net.mcreator.biomespls.entity.GhostEntity;
import net.mcreator.biomespls.entity.AshsoulEntity;
import net.mcreator.biomespls.entity.AshslimeEntity;
import net.mcreator.biomespls.entity.AshSkeletonEntity;
import net.mcreator.biomespls.BiomesplsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BiomesplsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BiomesplsMod.MODID);
	public static final RegistryObject<EntityType<ThrowingTorchEntity>> THROWING_TORCH = register("projectile_throwing_torch",
			EntityType.Builder.<ThrowingTorchEntity>of(ThrowingTorchEntity::new, MobCategory.MISC).setCustomClientFactory(ThrowingTorchEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<AshsoulEntity>> ASHSOUL = register("ashsoul",
			EntityType.Builder.<AshsoulEntity>of(AshsoulEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(AshsoulEntity::new).fireImmune().sized(0.7999999999999999f, 2f));
	public static final RegistryObject<EntityType<GhostEntity>> GHOST = register("ghost",
			EntityType.Builder.<GhostEntity>of(GhostEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(GhostEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<AshslimeEntity>> ASHSLIME = register("ashslime",
			EntityType.Builder.<AshslimeEntity>of(AshslimeEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(AshslimeEntity::new).fireImmune().sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<AshSkeletonEntity>> ASH_SKELETON = register("ash_skeleton",
			EntityType.Builder.<AshSkeletonEntity>of(AshSkeletonEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AshSkeletonEntity::new).fireImmune().sized(0.7f, 2f));
	public static final RegistryObject<EntityType<LavaslimeEntity>> LAVASLIME = register("lavaslime",
			EntityType.Builder.<LavaslimeEntity>of(LavaslimeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LavaslimeEntity::new).fireImmune().sized(0.6f, 0.6f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			AshsoulEntity.init();
			GhostEntity.init();
			AshslimeEntity.init();
			AshSkeletonEntity.init();
			LavaslimeEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ASHSOUL.get(), AshsoulEntity.createAttributes().build());
		event.put(GHOST.get(), GhostEntity.createAttributes().build());
		event.put(ASHSLIME.get(), AshslimeEntity.createAttributes().build());
		event.put(ASH_SKELETON.get(), AshSkeletonEntity.createAttributes().build());
		event.put(LAVASLIME.get(), LavaslimeEntity.createAttributes().build());
	}
}
