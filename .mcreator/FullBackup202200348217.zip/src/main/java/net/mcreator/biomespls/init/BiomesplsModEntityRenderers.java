
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.biomespls.client.renderer.LavaslimeRenderer;
import net.mcreator.biomespls.client.renderer.GhostRenderer;
import net.mcreator.biomespls.client.renderer.AshsoulRenderer;
import net.mcreator.biomespls.client.renderer.AshslimeRenderer;
import net.mcreator.biomespls.client.renderer.AshSkeletonRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BiomesplsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(BiomesplsModEntities.THROWING_TORCH.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.ASHSOUL.get(), AshsoulRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.GHOST.get(), GhostRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.ASHSLIME.get(), AshslimeRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.ASH_SKELETON.get(), AshSkeletonRenderer::new);
		event.registerEntityRenderer(BiomesplsModEntities.LAVASLIME.get(), LavaslimeRenderer::new);
	}
}
