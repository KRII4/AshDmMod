
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.biomespls.item.ThrowingTorchItem;
import net.mcreator.biomespls.item.ScorchedDimensionItem;
import net.mcreator.biomespls.item.PilentiumItem;
import net.mcreator.biomespls.item.ElementalShardItem;
import net.mcreator.biomespls.item.ElementItem;
import net.mcreator.biomespls.item.AshwaterItem;
import net.mcreator.biomespls.item.AshSoulHeartItem;
import net.mcreator.biomespls.BiomesplsMod;

public class BiomesplsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BiomesplsMod.MODID);
	public static final RegistryObject<Item> ASHGRASS = block(BiomesplsModBlocks.ASHGRASS, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> SCORCHEDEARTH = block(BiomesplsModBlocks.SCORCHEDEARTH, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ASH_ROCK = block(BiomesplsModBlocks.ASH_ROCK, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> SCORCHED_DIMENSION = REGISTRY.register("scorched_dimension", () -> new ScorchedDimensionItem());
	public static final RegistryObject<Item> ASHWATER_BUCKET = REGISTRY.register("ashwater_bucket", () -> new AshwaterItem());
	public static final RegistryObject<Item> SCORCHED_WOOD = block(BiomesplsModBlocks.SCORCHED_WOOD, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ELEMENTAL_ORE_BLOCK = block(BiomesplsModBlocks.ELEMENTAL_ORE_BLOCK, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ASH_COAL = block(BiomesplsModBlocks.ASH_COAL, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ELEMENT = REGISTRY.register("element", () -> new ElementItem());
	public static final RegistryObject<Item> BROKEN_ASH_STONE = block(BiomesplsModBlocks.BROKEN_ASH_STONE, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ELEMENTAL_SHARD = REGISTRY.register("elemental_shard", () -> new ElementalShardItem());
	public static final RegistryObject<Item> VERY_BREAKED_ASH_STONE = block(BiomesplsModBlocks.VERY_BREAKED_ASH_STONE,
			BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> THROWING_TORCH = REGISTRY.register("throwing_torch", () -> new ThrowingTorchItem());
	public static final RegistryObject<Item> PILENTIUM_ORE = block(BiomesplsModBlocks.PILENTIUM_ORE, BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> PILENTIUM = REGISTRY.register("pilentium", () -> new PilentiumItem());
	public static final RegistryObject<Item> SCORCH_WOOD_NO_FLAME = block(BiomesplsModBlocks.SCORCH_WOOD_NO_FLAME,
			BiomesplsModTabs.TAB_SCORCHED_BIOME);
	public static final RegistryObject<Item> ASHSOUL = REGISTRY.register("ashsoul_spawn_egg",
			() -> new ForgeSpawnEggItem(BiomesplsModEntities.ASHSOUL, -14408668, -4499968,
					new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME)));
	public static final RegistryObject<Item> ASH_SOUL_HEART = REGISTRY.register("ash_soul_heart", () -> new AshSoulHeartItem());
	public static final RegistryObject<Item> GHOST = REGISTRY.register("ghost_spawn_egg", () -> new ForgeSpawnEggItem(BiomesplsModEntities.GHOST,
			-16777216, -65536, new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME)));
	public static final RegistryObject<Item> ASHSLIME = REGISTRY.register("ashslime_spawn_egg",
			() -> new ForgeSpawnEggItem(BiomesplsModEntities.ASHSLIME, -15329770, -26368,
					new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME)));
	public static final RegistryObject<Item> ASH_SKELETON = REGISTRY.register("ash_skeleton_spawn_egg",
			() -> new ForgeSpawnEggItem(BiomesplsModEntities.ASH_SKELETON, -14475497, -31232,
					new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME)));
	public static final RegistryObject<Item> LAVASLIME = REGISTRY.register("lavaslime_spawn_egg",
			() -> new ForgeSpawnEggItem(BiomesplsModEntities.LAVASLIME, -26368, -11980261,
					new Item.Properties().tab(BiomesplsModTabs.TAB_SCORCHED_BIOME)));
	public static final RegistryObject<Item> ROCKY_ROCK = block(BiomesplsModBlocks.ROCKY_ROCK, BiomesplsModTabs.TAB_SCORCHED_BIOME);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
