package net.mcreator.biomespls.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;

import net.minecraft.world.entity.Entity;

import net.mcreator.biomespls.entity.AshSkeletonEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class AshSkeletonOnEntityTickUpdateProcedure {
	@SubscribeEvent
	public static void onEntitySetsAttackTarget(LivingSetAttackTargetEvent event) {
		execute(event, event.getTarget());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof AshSkeletonEntity) {
			((AshSkeletonEntity) entity).animationprocedure = "sprint";
		}
	}
}
