
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.biomespls.BiomesplsMod;

public class BiomesplsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, BiomesplsMod.MODID);
	public static final RegistryObject<SoundEvent> ASHAMBIENT = REGISTRY.register("ashambient",
			() -> new SoundEvent(new ResourceLocation("biomespls", "ashambient")));
	public static final RegistryObject<SoundEvent> SLIMEJUMP4 = REGISTRY.register("slimejump4",
			() -> new SoundEvent(new ResourceLocation("biomespls", "slimejump4")));
}
