
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.biomespls.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.biomespls.block.VeryBreakedAshStoneBlock;
import net.mcreator.biomespls.block.ScorchedearthBlock;
import net.mcreator.biomespls.block.ScorchedWoodBlock;
import net.mcreator.biomespls.block.ScorchedDimensionPortalBlock;
import net.mcreator.biomespls.block.ScorchWoodNoFlameBlock;
import net.mcreator.biomespls.block.RockyRockBlock;
import net.mcreator.biomespls.block.PilentiumOreBlock;
import net.mcreator.biomespls.block.ElementalOreBlockBlock;
import net.mcreator.biomespls.block.BrokenAshStoneBlock;
import net.mcreator.biomespls.block.AshwaterBlock;
import net.mcreator.biomespls.block.AshgrassBlock;
import net.mcreator.biomespls.block.AshRockBlock;
import net.mcreator.biomespls.block.AshCoalBlock;
import net.mcreator.biomespls.BiomesplsMod;

public class BiomesplsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, BiomesplsMod.MODID);
	public static final RegistryObject<Block> ASHGRASS = REGISTRY.register("ashgrass", () -> new AshgrassBlock());
	public static final RegistryObject<Block> SCORCHEDEARTH = REGISTRY.register("scorchedearth", () -> new ScorchedearthBlock());
	public static final RegistryObject<Block> ASH_ROCK = REGISTRY.register("ash_rock", () -> new AshRockBlock());
	public static final RegistryObject<Block> SCORCHED_DIMENSION_PORTAL = REGISTRY.register("scorched_dimension_portal",
			() -> new ScorchedDimensionPortalBlock());
	public static final RegistryObject<Block> ASHWATER = REGISTRY.register("ashwater", () -> new AshwaterBlock());
	public static final RegistryObject<Block> SCORCHED_WOOD = REGISTRY.register("scorched_wood", () -> new ScorchedWoodBlock());
	public static final RegistryObject<Block> ELEMENTAL_ORE_BLOCK = REGISTRY.register("elemental_ore_block", () -> new ElementalOreBlockBlock());
	public static final RegistryObject<Block> ASH_COAL = REGISTRY.register("ash_coal", () -> new AshCoalBlock());
	public static final RegistryObject<Block> BROKEN_ASH_STONE = REGISTRY.register("broken_ash_stone", () -> new BrokenAshStoneBlock());
	public static final RegistryObject<Block> VERY_BREAKED_ASH_STONE = REGISTRY.register("very_breaked_ash_stone",
			() -> new VeryBreakedAshStoneBlock());
	public static final RegistryObject<Block> PILENTIUM_ORE = REGISTRY.register("pilentium_ore", () -> new PilentiumOreBlock());
	public static final RegistryObject<Block> SCORCH_WOOD_NO_FLAME = REGISTRY.register("scorch_wood_no_flame", () -> new ScorchWoodNoFlameBlock());
	public static final RegistryObject<Block> ROCKY_ROCK = REGISTRY.register("rocky_rock", () -> new RockyRockBlock());
}
